let screen;
let startButton, lvlMenuButton;
let lvlButton, leftButton, rightButton;
let titleButton, ex1Button, ex2Button, ex3Button;

let win, lose;

let againButton, nextButton, playButton, insButton;

let cS = "Comic Sans MS";

let bgC;

let wRatio;
let hRatio;

let startTime;

let lives;

let timer;

let ins;

let img1, img2, img3;

let victory, ding, buzzer, rBuzzer;

let vPlayed, bPlayed;

let timeBonus, livesBonus, finalScore;

function preload(){
  img1 = loadImage('images/img1.png');
  img2 = loadImage('images/img2.png');
  img3 = loadImage('images/img3.png');
  
  victory = loadSound('sounds/victory.mp3');
  ding = loadSound('sounds/ding.mp3');
  buzzer = loadSound('sounds/buzzer.mp3');
  rBuzzer = loadSound('sounds/rBuzzer.mp3');
}

function setup() {  
  
  vPlayed = false;
  bPlayed = false;
  
  textAlign('center');
  bgC = color(204,255,255);
  
  wRatio = windowWidth/600;
  hRatio = windowHeight/400;
  
  createCanvas(windowWidth, windowHeight);
  textFont(cS);
  textSize(40 * windowWidth/600);
  fill("blue");
  screen = 1;
  console.log(screen);
  console.log(windowWidth);
  console.log(windowHeight);
  
  insButton = createButton("How to play");
  styleButton(insButton, 265, 355, 75, 30, 10);
  insButton.mouseClicked(function(){ins = !ins;});
  insButton.hide();

  nextButton = createButton("Next Activity");
  styleButton(nextButton, 250, 250, 100, 50, 14);
  nextButton.mouseClicked(function(){exSetup();nextScreen();});
  nextButton.hide();
  
  againButton = createButton("Try Again");
  styleButton(againButton, 250, 175, 100, 50, 14);
  againButton.mouseClicked(function(){lives = 3;exSetup();});
  againButton.hide();
  
  startButton = createButton("Start");
  styleButton(startButton, 225, 175, 150, 75, 25);
  startButton.mouseClicked(nextScreen);
  
  lvlMenuButton = createButton("Level Select");  
  styleButton(lvlMenuButton, 250, 270, 100, 50, 14);
  lvlMenuButton.mouseClicked(function(){screen = 0;exErase();});
  
  lvlButton = createButton("Level Select");
  styleButton(lvlButton, 450, 50, 100, 50, 14);
  lvlButton.mouseClicked(function(){screen = 0;exErase();})
  
  leftButton = createButton("Start Screen");
  styleButton(leftButton, 50, 300, 100, 50, 14);
  leftButton.mouseClicked(prevScreen);
  
  rightButton = createButton("Next Activity");
  styleButton(rightButton, 450, 300, 100, 50, 14);
  rightButton.mouseClicked(nextScreen);
  
  titleButton = createButton("Start Screen");
  styleButton(titleButton, 90, 100, 200, 100, 25);
  titleButton.mouseClicked(nextScreen);
  
  ex1Button = createButton("Activity 1");
  styleButton(ex1Button, 310, 100, 200, 100, 25);
  ex1Button.mouseClicked(function(){exErase();screen = 2;exSetup();});
  
  ex2Button = createButton("Activity 2");
  styleButton(ex2Button, 90, 220, 200, 100, 25);
  ex2Button.mouseClicked(function(){exErase();screen = 3;exSetup();});
  
  ex3Button = createButton("Activity 3");
  styleButton(ex3Button, 310, 220, 200, 100, 25);
  ex3Button.mouseClicked(function(){exErase();screen = 4;exSetup();});
}

function draw() {  
  fill(bgC);
  stroke(0, 255, 255)
  strokeWeight(10);
  rect(5, 5, windowWidth - 10, windowHeight - 10, 30);
  strokeWeight(1)
  fill("blue");
  stroke("blue")
  
  screen = (screen > 4)? 1:screen;
  console.log(screen);
  
  switch(screen){
    case 0:
      lvlSelect();
      break;
    case 1:
      titleScreen();
      break;
    default:
      exScreen(screen - 1);
  }  
}

function styleButton(button, x, y, xSize, ySize){
  button.style('color','blue')
  button.style('background-color','rgb(204, 204, 255)');
  button.style('font-family', cS);
  button.style('border-width','thick');
  button.style('border-color','blue');
  button.style('border-radius',(12 * hRatio) +'px');  
  button.position(x * wRatio,y * hRatio);
  button.size(xSize * wRatio,ySize * hRatio);

}

function styleButton(button, x, y, xSize, ySize, fontSize){
  button.style('color','blue')
  button.style('background-color','rgb(204, 204, 255)');
  button.style('font-family', cS);
  button.style('border-width','thick');
  button.style('border-color','blue');
  button.style('border-radius','12px');  
  button.position(windowWidth * x/600,windowHeight * y/400);
  button.size(windowWidth * xSize/600,windowHeight * ySize/400);
  button.style('font-size',fontSize * hRatio + 'px');
}

function titleScreen(){
  insButton.hide();
  
  text("Project FMS",windowWidth/2,100*hRatio)
  startButton.show();
  lvlMenuButton.show()
  
  rightButton.hide();
  leftButton.hide();
  lvlButton.hide();
  
  titleButton.hide();
  ex1Button.hide();
  ex2Button.hide();
  ex3Button.hide();
  
}

function exScreen(ex){
  insButton.show();
  
  rightButton.show();
  leftButton.show();
  lvlButton.show();
  
  titleButton.hide();
  ex1Button.hide();
  ex2Button.hide();
  ex3Button.hide();
  
  startButton.hide();
  lvlMenuButton.hide();
  
  leftButton.html((ex > 1)? "Previous Activity": "Start Screen");
  
  rightButton.html((ex < 3)? "Next Activity": "Start Screen");
  
  text("Lives: " + lives,windowWidth/2,350 * hRatio);
  
  textAlign('left');
  text("Time: " + timer,20 * wRatio,65 * hRatio);
  textAlign('center');
  
  switch(ex){
    case 1:
      strokeWeight(10);
      stroke(0, 255, 255);
      text("Activity 1",windowWidth/2,65*hRatio);
      ex1();
      fill('blue');
      noStroke();
      break;
    case 2:
      strokeWeight(10);
      stroke(0, 255, 255);
      text("Activity 2",windowWidth/2,65*hRatio);
      ex2();
      noStroke();
      fill('blue');
      break;
    case 3:
      strokeWeight(10);
      stroke(0, 255, 255);
      text("Activity 3",windowWidth/2,65*hRatio);
      ex3();
      noStroke();
      fill('blue');
      break;
    default:
      titleScreen();    
  }
  if(ins){instructions();}
  
}

function nextScreen(){
  exErase();
  screen++;
  console.log(screen);
  exSetup();
}

function prevScreen(){
  exErase();
  screen--;
  console.log(screen);
  exSetup();
}

function lvlSelect(){
  insButton.hide();
  startButton.hide();
  lvlMenuButton.hide()
  rightButton.hide();
  leftButton.hide();
  lvlButton.hide();
  
  titleButton.show();
  ex1Button.show();
  ex2Button.show();
  ex3Button.show();
  
  text("Level Select",windowWidth/2,50 * hRatio);
  
  console.log(screen);
}

function ex1(){
  ex1Draw();
}

function ex2(){
  ex2Draw();
}

function ex3(){
  ex3Draw();
}

function exSetup(){  
  vPlayed = false;
  bPlayed = false;
  
  ins = false;
  
  nextButton.html("Next Activity");
  
  againButton.hide();
  nextButton.hide();
  
  ex = screen - 1;
  
  lives = 3;
  
  timer = 0;
  
  startTime = seconds();

  win = false;
  
  lose = false;
  
  timeBonus = 0;
    
  livesBonus = 0;
    
  finalScore = 0;
      
   switch(ex){
    case 1:
      ex1Setup();
      break;
    case 2:
      ex2Setup();
      break;
    case 3:
      nextButton.html("Start Screen");
      ex3Setup(); 
      break;
    default:
      titleScreen();
  }
}

function exErase(){
  ex = screen - 1;
   switch(ex){
    case 1:
      ex1Erase();
      break;
    case 2:
      ex2Erase();
      break;
    case 3:
      ex3Erase();
      break;
  }
}

function touchStarted(){
  ex = screen - 1;
   switch(ex){
    case 1:
      ex1touchStarted();
      break;
    case 2:
      ex2touchStarted();
      break;
    case 3:
      ex3touchStarted();
      break;
    
  }
}

function touchMoved(){
  ex = screen - 1;
   switch(ex){
    case 1:
      ex1touchMoved();
      break;
    case 2:
      ex2touchMoved();
      break;
    case 3:
      ex3touchMoved();
      break;
    
  }
}

function touchEnded(){
  ex = screen - 1;
   switch(ex){
    case 1:
      ex1touchEnded();
      break;
    case 2:
      ex2touchEnded();
      break;
    case 3:
      ex3touchEnded();
      break;
    
  }
}

function instructions(){  
  fill(bgC);
  stroke(0, 255, 255)
  strokeWeight(10);
  rect(150 * wRatio, 0 * hRatio, 300 * wRatio, 400 * hRatio);
  
  textSize(25 * wRatio);
  
  fill('blue');
  text("How to play:", windowWidth/2, 50 * hRatio);

  let img;
  
  noStroke();
  
  textSize(15 * wRatio);
  
  ex = screen - 1;
   switch(ex){
    case 1:
       image(img1,150 * wRatio,(200 - 50) * hRatio, 300 * wRatio, 200 * hRatio);
       text("- Red Circle must reach\nYellow Circle\n- Red Circle must not lose\ncontact with Blue Line", windowWidth/2, 80 * hRatio);
      break;
    case 2:
       image(img2,150 * wRatio,(200 - 50) * hRatio, 300 * wRatio, 200 * hRatio);
       text("- Red Circles must touch\neach other\n- Red Circles will return to original\nposition upon release", windowWidth/2, 80 * hRatio);
      break;
    case 3:
       image(img3,150 * wRatio,(200 - 50) * hRatio, 300 * wRatio, 200 * hRatio);
       text("- Red Pieces (positions randomized)\nmust connect with matching connector\n- Life is lost upon attempting\nan incorrect match", windowWidth/2, 80 * hRatio);
      break;
  }  
  textSize(40 * wRatio);
}

function finishScreen(){
  if(win || lose){
    game1Run = false;
    game2Run = false;
    game3Run = false;
    
    timer = timer % 20;
    
    timeBonus = 40 - 2*timer;
    
    livesBonus = lives * 20;
    
    finalScore = timeBonus + livesBonus + 10;
    
    stroke(win? 'green':'red');
    fill(win? 'lime':'orange');
    
    strokeWeight(10);
    
    rect(150 * wRatio, 50 * hRatio, 300 * wRatio, 300 * hRatio);
    textSize(25 * wRatio);
    againButton.show();
    
    if(win){
      if(!vPlayed){victory.play();vPlayed = true}
      nextButton.show();
      n = 4 - lives;
      text("Level Completed",windowWidth/2,90 * hRatio);
      noStroke();
      fill('blue');
      text("Time Bonus: " + timeBonus,windowWidth/2,130 * hRatio);
      text("Lives Bonus: " + livesBonus,windowWidth/2,160 * hRatio);
      stroke(bgC);
      text("Final Score: " + finalScore,windowWidth/2,330 * hRatio);
      noStroke();
    }
    else{
      if(!bPlayed){buzzer.play();bPlayed = true}
      text("Level Failed",windowWidth/2,100 * hRatio);
    }
    textSize(40 * wRatio);
  }
  else{againButton.hide();nextButton.hide()}
}

function exRestart(){
  vPlayed = false;
  bPlayed = false;
  
  if(lives >= 0){rBuzzer.play();}
  
  ex = screen - 1;
   switch(ex){
    case 1:
      ex1Restart();
      break;
    case 2:
      ex2Restart();
      break;
    case 3:
      exSetup();
      break;
  }
}

function seconds(){
  return (int)(millis()/1000);
}