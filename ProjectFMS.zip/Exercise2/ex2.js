let c1Pos, c1InitPos, c1Delta;
let c2Pos, c2InitPos, c2Delta;
let r, d, t;
let game2Run;
let cFill;
let t1, t2;
function ex2Setup(){  
  absPos = createVector(200 * wRatio, 200 * windowHeight/400);
  c1InitPos = createVector(absPos.x, absPos.y);
  c2InitPos = createVector(windowWidth - c1InitPos.x, c1InitPos.y);
  
  c1Pos = createVector(c1InitPos.x, c1InitPos.y);
  c2Pos = createVector(c2InitPos.x, c2InitPos.y);
  
  c1Delta = createVector();
  c2Delta = createVector();
  
  cFill = 'red';
  
  r = 50 * wRatio;
  d = r * 2;
  t = false;
  
  t1 = createVector();
  t2 = createVector();
  
  game2Run = true;
  
}

function ex2Draw(){
  if(game2Run){timer = seconds() - startTime;}
  
  noStroke();
  
  fill(cFill);
  circle(c1Pos.x, c1Pos.y, d);
  
  fill(cFill);
  circle(c2Pos.x, c1Pos.y, d);
  
  checkWin();
  
  fill('blue');
  //text("Lives: " + lives,200 * wRatio,350 * hRatio);
  
  finishScreen();
  
  if(lives < 0){
    lose = true;
  }
}

function ex2Restart(){
  c1Pos = createVector(c1InitPos.x, c1InitPos.y);
  c2Pos = createVector(c2InitPos.x, c2InitPos.y);
  
  t = false;
  
  cFill = 'red';
  
  win = false;
  lose = false;
  
  game2Run = true;
}

function ex2touchStarted(){
  if(game2Run && bothTouched()){
    t = true;
    cFill = 'green';
    
    setTouches();
    
    c1Delta.x = t1.x - c1Pos.x;
    c1Delta.y = t1.y - c1Pos.y;
    
    c2Delta.x = t2.x - c2Pos.x;
    c2Delta.y = t2.y - c2Pos.y;
  }
}

function ex2touchMoved(){
  if(game2Run && t){
    
    setTouches();
    
    c1Pos.x = t1.x - c1Delta.x;
    c1Pos.y = t1.y - c1Delta.y;
    console.log(t1.x);
    console.log(t1.y);
    
    c2Pos.x = t2.x - c2Delta.x;
    c2Pos.y = t2.y - c2Delta.y;
    
    c1Delta.x = t1.x - c1Pos.x;
    c1Delta.y = t1.y - c1Pos.y;
    
    c2Delta.x = t2.x - c2Pos.x;
    c2Delta.y = t2.y - c2Pos.y;
  }
}

function ex2touchEnded(){
  if(game2Run && t){
    lives--;
    if(lives >= 0){rBuzzer.play();}
  }
}

function checkWin(){
  win = dist(c1Pos.x,c1Pos.y,c2Pos.x,c2Pos.y) <= d * 3/4;
  game2Run = !win;
}

function ex2Erase(){
  againButton.hide();
  nextButton.hide();
  game2Run = false;
}

function bothTouched(){
  return (touches.length < 2)?
    false
  :
    (inCircle(c1Pos, touches[0]) && inCircle( c2Pos, touches[1])) 
    || 
    (inCircle(c1Pos, touches[1]) && inCircle( c2Pos, touches[0]))
  ;
}

function inCircle(c, p){
  return (dist(c.x, c.y, p.x, p.y) <= r);
}

function setTouches(){
  for(var i = 0;i < touches.length; i++){
    if(inCircle( c1Pos, touches[i])){
       t1.x = touches[i].x;
       t1.y = touches[i].y;
    }
    if(inCircle( c2Pos, touches[i])){
       t2.x = touches[i].x;
       t2.y = touches[i].y;
      
    }
  }
}