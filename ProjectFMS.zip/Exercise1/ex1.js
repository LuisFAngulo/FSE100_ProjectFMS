let f, s, m, l, w;
var absPos, cPos, gPos;
let v1, v2, v3, v4, v5;
let game1Run;

let vect1A, vect1B;
let vect2A, vect2B;
let vect3A, vect3B;
let vect4A, vect4B;
let vect5A, vect5B;
function ex1Setup() {
  game1Run = true;
  
  textFont(cS);
  
  l = windowWidth/5;
  h = windowHeight/3
  
  w = 10;
  
  strokeWeight(10);
  
  strokeWeight(1);
  
  delta = createVector();
  
  absPos = createVector(150 * wRatio, 125 * hRatio);
  
  v1 = createVector(absPos.x - w/2,absPos.y);
  
  v2 = createVector(v1.x, v1.y + h);
  
  v3 = createVector(v2.x + l, v2.y - h + w);
  
  v4 = createVector(v3.x, v3.y);
  
  v5 = createVector(v4.x + l, v4.y);
  
  gPos = createVector(v5.x + w/2, v2.y);
  
  vect1A = createVector(v1.x - 25 * hRatio, v1.y - 25 * hRatio);
  vect1B = createVector(v1.x + w + 25 * hRatio, v1.y + h + 25 * hRatio);
  
  vect2A = createVector(v2.x - 25 * hRatio, v2.y - 25 * hRatio);
  vect2B = createVector(v2.x + l + 25 * hRatio, v2.y + w + 25 * hRatio);
  
  vect3A = createVector(v3.x - 25 * hRatio, v3.y - 25 * hRatio);
  vect3B = createVector(v3.x + w + 25 * hRatio, v3.y + h + 25 * hRatio);
  
  vect4A = createVector(v4.x - 25 * hRatio, v4.y - 25 * hRatio);
  vect4B = createVector(v4.x + l + 25 * hRatio, v4.y + w + 25 * hRatio);
  
  vect5A = createVector(v5.x - 25 * hRatio, v5.y - 25 * hRatio);
  vect5B = createVector(v5.x + w + 25 * hRatio, v5.y + h + 25 * hRatio);
  
  cPos = createVector(absPos.x, absPos.y);
  
  f = 'red';
  s = 'red';
  
  m = false;
  
}
function ex1Draw() {
  if(game1Run){timer = seconds() - startTime;}
  strokeWeight(0)
  
  rect(v1.x,v1.y, w, h);
  rect(v2.x,v2.y, l, w);
  rect(v3.x,v3.y, w, h);
  rect(v4.x,v4.y, l, w);
  rect(v5.x,v5.y, w, h);
  
  fill('yellow');  
  circle(gPos.x, gPos.y, 70 * hRatio);
  
  fill(f);
  stroke(s);
  
  circle(cPos.x, cPos.y, 50 * hRatio);
  
  if(!isTouchingLine()){
    lives--;
    exRestart(); 
  }
  
  if(dist(cPos.x, cPos.y, gPos.x, gPos.y) < 19 *wRatio){
     win = true;
  }
  
  
  fill('blue');
  //text("Lives: " + lives,200 * wRatio,350 * hRatio);
  
  finishScreen();
  
  if(lives < 0){
    lose = true;
  }
}


function ex1touchStarted(){
  if(game1Run && dist(cPos.x, cPos.y, mouseX, mouseY) <= 25 * hRatio){
    f = 'green';
    s = 'green';
    m = true;
  }
}

function ex1touchMoved(){
  if(game1Run && m){
    cPos.x += mouseX - pmouseX;
    cPos.y += mouseY - pmouseY;
  }
}

function ex1touchEnded(){
  if(game1Run && m){
    lives--;
    exRestart();
  }
}

function ex1Restart(){
  f = 'red';
  s = 'red';
  m = false;
  cPos = createVector(absPos.x, absPos.y);
  win = false;
  lose = false;
  game1Run = true;
}

function isTouchingLine(){  
  return (isInArea(cPos, vect1A, vect1B) || isInArea(cPos, vect2A, vect2B) || isInArea(cPos, vect3A, vect3B) || isInArea(cPos, vect4A, vect4B) || isInArea(cPos, vect5A, vect5B));
  
}
  
function isInArea( pos, vert1, vert2){
  return (isBetween(pos.x, vert1.x, vert2.x) && isBetween(pos.y, vert1.y, vert2.y));
}
  
function isBetween(n, min, max){
  return(n > min && n < max);
}

function ex1Erase(){
  againButton.hide();
  nextButton.hide();
  game1Run = false;
}