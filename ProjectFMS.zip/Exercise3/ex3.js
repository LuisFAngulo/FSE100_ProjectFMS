let game3Run;
let place1, place2, place3;
let sol1, sol2, sol3;
let p1, p2, p3;
let rand;
let h, dr;
let pW, pH, sW, sH;
let p1C, p2C, p3C;
let comp;
let d1Played, d2Played, d3Played;
function ex3Setup(){  
  game3Run = true;
  
  d1Played = false;
  d2Played = false;
  d3Played = false;
  
  comp = 0;
  
  p1C = 'red';
  p2C = 'red';
  p3C = 'red';
  
  dr = 0;
  
  w = windowWidth/3;
  h = windowHeight/5;
  
  pW = w * 2/5;
  pH = h;
  
  sW = w/10;
  sH = h/5;
  
  fill('blue');
  noStroke();
  rect(10, windowHeight/5, w, h * 3);
  stroke('skyblue');
  strokeWeight(10);
  line(20, windowHeight * 2/5, w, h * 2);
  line(20, windowHeight * 3/5, w, h * 3);
  
  place1 = createVector(windowWidth - w + sW, windowHeight/10);
  place2 = createVector(windowWidth - w + sW, windowHeight/2 - h/2);
  place3 = createVector(windowWidth - w + sW, windowHeight/10*7);
  
  sol1 = createVector(10 + w, h);
  sol2 = createVector(10 + w, h*2);
  sol3 = createVector(10 + w, h*3);
  
  p1 = createVector(0, 0, 0);
  p2 = createVector(0, 0, 0);
  p3 = createVector(0, 0, 0);
  
  mixPieces();
  
}

function ex3Draw(){
  if(game3Run){timer = seconds() - startTime;}


  drawPuzzle();
  
  fill('blue');
  
  comp = p1.z + p2.z + p3.z;
  
  drawPiece(1, p1, p1C);
  drawPiece(2, p2, p2C);
  drawPiece(3, p3, p3C);
  
  finishScreen();
  
  if(lives < 0){
    lose = true;
    
  }
  if(comp >= 3){
    win = true;
    ding.stop();
  }
}

function drawPuzzle(){
  fill('blue');
  noStroke();
  rect(10, windowHeight/5, w, h * 3);
  stroke('skyblue');
  strokeWeight(2 * hRatio);
  line(20, windowHeight * 2/5, w, h * 2);
  line(20, windowHeight * 3/5, w, h * 3);
  
  noStroke();
  fill(bgC);
  
  rect(10 + w - sW, h + sH/2, sW, sH);
  rect(10 + w - sW, h + sH* 7/2, sW, sH);
  
  rect(10 + w - sW, 2*h + sH/2 , sW, sH); 
  rect(10 + w - sW, 2*h + sH*2, sW, sH); 
  rect(10 + w - sW, 2*h + sH* 7/2, sW, sH);
  
  rect(10 + w - sW, 3*h + sH/2 , sW, sH); 
  rect(10 + w - sW, 3*h + sH*5/2, sW, sH); 
  rect(10 + w - sW, 3*h + sH* 7/2, sW, sH); 
}

function ex3Erase(){
  againButton.hide();
  nextButton.hide();
  game3Run = false;
}

function ex3touchStarted(){
  if(game3Run){
    mousePos = createVector(mouseX, mouseY);    
    
    if(isInArea(mousePos,p1,createVector(p1.x + w, p1.y + h))){
      dr = 1;
    }
    else if(isInArea(mousePos,p2,createVector(p2.x + w, p2.y + h))){
      dr = 2;
    }
    else if(isInArea(mousePos,p3,createVector(p3.x + w, p3.y + h))){
      dr = 3;
    }
  }
}

function ex3touchMoved(){
  switch(dr){
    case 1:
      if(p1.z == 1){break;}
      p1.x += mouseX - pmouseX;
      p1.y += mouseY - pmouseY;
      break;
    case 2:
      if(p2.z == 1){break;}
      p2.x += mouseX - pmouseX;
      p2.y += mouseY - pmouseY;
      break;
    case 3:
      if(p3.z == 1){break;}
      p3.x += mouseX - pmouseX;
      p3.y += mouseY - pmouseY;
      break;
  }
}

function ex3touchEnded(){
  dr = 0;
  
  if(checkSol(sol1,p1) && !d1Played){
    p1.x = sol1.x;
    p1.y = sol1.y;
    p1.z = 1;
    p1C = 'green';
    ding.play();
    d1Played = true;
  }
  if(checkSol(sol2,p2) && !d2Played){
    p2.x = sol2.x;
    p2.y = sol2.y;
    p2.z = 1;
    p2C = 'green';
    ding.play();
    d2Played = true;
  }
  if(checkSol(sol3,p3) && !d3Played){
    p3.x = sol3.x;
    p3.y = sol3.y;
    p3.z = 1;
    p3C = 'green';
    ding.play();
    d3Played = true;
  }

  if(checkSol(sol1,p2) || checkSol(sol1,p3) || checkSol(sol2,p1) || checkSol(sol2,p3) || checkSol(sol3,p1) || checkSol(sol3,p2)){
    lives--;
    if(lives >= 0){rBuzzer.play();}
  }
  
  console.log(comp);
}

function checkSol(tSol, tP){
  return dist(tSol.x, tSol.y, tP.x, tP.y) < sH/4;
}

function drawPiece(n, pos, col){
  fill(col);
  
  noStroke();
  
  rect(pos.x, pos.y, pW, pH);
  
  rect(pos.x - sW, pos.y + sH/2, sW, sH);
  
  rect(pos.x - sW, pos.y + sH * 7/2, sW, sH);
  
  
  switch(n){
    case 2:
      rect(pos.x - sW, pos.y + sH*2, sW, sH);
      break;
    case 3:
      rect(pos.x - sW, pos.y + sH*5/2, sW, sH);
      break;         
  }
  
}

function mixPieces(){
  rand = random(6);
  console.log(rand);
  
  if(rand >= 0 && rand < 1){
    p1.x = place1.x;
    p2.x = place2.x;
    p3.x = place3.x;
    
    p1.y = place1.y;
    p2.y = place2.y;
    p3.y = place3.y;
  }
  else if(rand >= 1 && rand < 2){
    p1.x = place1.x;
    p2.x = place3.x;
    p3.x = place2.x;
    
    p1.y = place1.y;
    p2.y = place3.y;
    p3.y = place2.y;
     
  }
  else if(rand >= 2 && rand < 3){
    p1.x = place2.x;
    p2.x = place1.x;
    p3.x = place3.x;
    
    p1.y = place2.y;
    p2.y = place1.y;
    p3.y = place3.y;
     
  }
  else if(rand >= 3 && rand < 4){
    p1.x = place2.x;
    p2.x = place3.x;
    p3.x = place1.x;
    
    p1.y = place2.y;
    p2.y = place3.y;
    p3.y = place1.y;
     
  }
  else if(rand >= 4 && rand < 5){
    p1.x = place3.x;
    p2.x = place1.x;
    p3.x = place2.x;
    
    p1.y = place3.y;
    p2.y = place1.y;
    p3.y = place2.y;
     
  }
  else if(rand >= 5 && rand < 6){
    p1.x = place3.x;
    p2.x = place2.x;
    p3.x = place1.x;
    
    p1.y = place3.y;
    p2.y = place2.y;
    p3.y = place1.y;
     
  }
}

function ex3Erase(){
  againButton.hide();
  nextButton.hide();
  game3Run = false;
}